		</article>
		<?php get_sidebar(); ?>
	</main>
	<footer id="footer">
		<section class="pagetop">
			<div class="inner">
				<a href="#wrap">ページトップ</a>
			</div>
		</section>
		<section class="copy">
			<div class="inner">
				Copyright © 1995-2015 eBay Inc. All Rights Reserved.  <a href="http://pages.ebay.com/help/policies/privacy-policy.html" target="_blank">User Agreement and Privacy</a>.
			</div>
		</section>
	</footer>
</div><!--  #wrap  -->
<?php wp_footer();?>

<!--GA Tag start -->
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-9633495-4']);
  _gaq.push(['_setDomainName', 'ebay.co.jp']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<!--GA Tag end -->

</body>
</html>